import { MenuCategoryItem, GalleryPhoto, WhyChooseItem, NavLinkItem } from '../types.ts';

export const RESTAURANT_INFO = {
  name: 'SKB Family Restaurant',
  tagline: 'Good Food. Great Taste. Happy Moments.',
  address: 'Angara, Ranchi, Jharkhand, India',
  shortLocation: 'Angara, Ranchi, Jharkhand',
  phone: '09798832616',
  displayPhone: '09798832616',
  phoneTelLink: 'tel:09798832616',
  whatsappLink: 'https://wa.me/919798832616',
  mapsSearchLink: 'https://www.google.com/maps/search/?api=1&query=SKB+Family+Restaurant%2C+Angara%2C+Ranchi%2C+Jharkhand',
  rating: 4.5,
  reviewCount: 46,
};

export const NAV_LINKS: NavLinkItem[] = [
  { name: 'Home', href: '#hero', id: 'hero' },
  { name: 'About', href: '#about', id: 'about' },
  { name: 'Why Us', href: '#why-us', id: 'why-us' },
  { name: 'Menu', href: '#menu', id: 'menu' },
  { name: 'Gallery', href: '#gallery', id: 'gallery' },
  { name: 'Reviews', href: '#reviews', id: 'reviews' },
  { name: 'Contact', href: '#contact', id: 'contact' },
];

export const WHY_CHOOSE_US: WhyChooseItem[] = [
  {
    id: 'family-friendly',
    title: 'Family Friendly',
    description: 'A warm, welcoming environment created specifically for relaxed meals with family and friends.',
    iconName: 'users',
  },
  {
    id: 'great-taste',
    title: 'Great Taste',
    description: 'Every dish is prepared with fresh ingredients and careful attention to deliver delicious flavors.',
    iconName: 'utensils',
  },
  {
    id: 'quality-experience',
    title: 'Quality Experience',
    description: 'Attentive service and thoughtful hospitality dedicated to making every visit comfortable and satisfying.',
    iconName: 'award',
  },
  {
    id: 'comfortable-dining',
    title: 'Comfortable Dining',
    description: 'Spacious, clean, and pleasant seating arrangements designed for relaxed conversations and enjoyment.',
    iconName: 'armchair',
  },
];

// Placeholder categories as requested in the prompt
export const MENU_CATEGORIES: MenuCategoryItem[] = [
  {
    id: 'starters',
    name: 'Starters',
    description: 'Appetizing selections to begin your meal with family and friends.',
    items: [
      {
        name: 'Crispy Appetizer Special',
        description: 'Seasoned starter prepared fresh to order with savory dips.',
        tag: 'Popular',
      },
      {
        name: 'Tandoor & Grill Starter Slot',
        description: 'Flavorful marinated starter charred to perfection.',
        tag: 'Chef Choice',
      },
      {
        name: 'Vegetarian Platter Starter Slot',
        description: 'Wholesome mix of fresh crispy starters with garden herbs.',
        tag: 'Family Favorite',
      },
      {
        name: 'Spiced Savory Bites Slot',
        description: 'Traditional spiced starter prepared fresh for sharing.',
      },
    ],
  },
  {
    id: 'main-course',
    name: 'Main Course',
    description: 'Hearty gravies, curries, and staples cooked for wholesome dining.',
    items: [
      {
        name: 'Signature Gravy Main Slot',
        description: 'Slow-simmered rich curry prepared with aromatic spices.',
        tag: 'Must Try',
      },
      {
        name: 'Classic Family Gravy Slot',
        description: 'Smooth, balanced spiced gravy ideal for rice or breads.',
        tag: 'Bestseller',
      },
      {
        name: 'Fresh Bread & Roti Assortment Slot',
        description: 'Freshly baked warm Indian breads brushed with natural butter.',
      },
      {
        name: 'Aromatic Rice & Biryani Main Slot',
        description: 'Fragrant seasoned basmati rice layered with delicate spices.',
        tag: 'Recommended',
      },
    ],
  },
  {
    id: 'family-specials',
    name: 'Family Specials',
    description: 'Generous combination platters designed for group gatherings.',
    items: [
      {
        name: 'Family Feast Platter Slot',
        description: 'A curated selection of starters, mains, and accompaniments for table sharing.',
        tag: 'Great For Groups',
      },
      {
        name: 'Celebration Combo Slot',
        description: 'Special celebratory assortment crafted for family dinners and get-togethers.',
        tag: 'Special',
      },
      {
        name: 'Weekend Gathering Selection Slot',
        description: 'Hearty multi-dish spread prepared for memorable dining moments.',
      },
    ],
  },
  {
    id: 'beverages',
    name: 'Beverages',
    description: 'Chilled coolers, traditional refreshments, and hot drinks.',
    items: [
      {
        name: 'Chilled Refreshment Cooler Slot',
        description: 'Crisp, rejuvenating iced beverage for a refreshing accompaniment.',
        tag: 'Chilled',
      },
      {
        name: 'Traditional Lassi / Cooler Slot',
        description: 'Creamy and refreshing traditional blend served cold.',
        tag: 'Classic',
      },
      {
        name: 'Hot Beverage Special Slot',
        description: 'Warm, freshly brewed tea or coffee to round off your meal.',
      },
    ],
  },
  {
    id: 'chefs-specials',
    name: 'Chef’s Specials',
    description: 'Signature kitchen recommendations prepared with extra care.',
    items: [
      {
        name: 'Chef’s Signature Delicacy Slot',
        description: 'House specialty dish crafted with prime seasonal ingredients and secret spices.',
        tag: 'Signature',
      },
      {
        name: 'Seasonal Taste Highlight Slot',
        description: 'Specialty creation honoring regional culinary traditions and taste.',
        tag: 'Limited',
      },
      {
        name: 'Royal Sizzler / Platter Slot',
        description: 'Sizzling hot presentation prepared for celebratory table dining.',
        tag: 'Popular',
      },
    ],
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'g1',
    title: 'Comfortable Dining Ambiance',
    category: 'ambiance',
    imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1200&auto=format&fit=crop',
    altText: 'Warm and inviting dining room setting with comfortable seating',
  },
  {
    id: 'g2',
    title: 'Aromatic Gravy & Traditional Breads',
    category: 'dishes',
    imageUrl: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=1200&auto=format&fit=crop',
    altText: 'Rich Indian curry dish served with fresh bread and aromatic spices',
  },
  {
    id: 'g3',
    title: 'Savory Sizzler & Starters',
    category: 'dishes',
    imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1200&auto=format&fit=crop',
    altText: 'Fresh hot starters and skewers prepared fresh for the table',
  },
  {
    id: 'g4',
    title: 'Family Gathering & Dining Tables',
    category: 'gathering',
    imageUrl: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=1200&auto=format&fit=crop',
    altText: 'Family dining table ready for dinner and pleasant conversation',
  },
  {
    id: 'g5',
    title: 'Fragrant Basmati Rice Specialty',
    category: 'dishes',
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=1200&auto=format&fit=crop',
    altText: 'Delicious fragrant spiced rice dish garnished with fresh herbs',
  },
  {
    id: 'g6',
    title: 'Freshly Baked Naan & Tandoori Breads',
    category: 'dishes',
    imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?q=80&w=1200&auto=format&fit=crop',
    altText: 'Hot fresh Indian breads served straight from the kitchen',
  },
  {
    id: 'g7',
    title: 'Refreshing Coolers & Drinks',
    category: 'dishes',
    imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=1200&auto=format&fit=crop',
    altText: 'Cooling beverages and drinks served chilled with citrus',
  },
  {
    id: 'g8',
    title: 'Welcoming Evening Atmosphere',
    category: 'ambiance',
    imageUrl: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=1200&auto=format&fit=crop',
    altText: 'Warm ambient lighting creating an inviting dining atmosphere',
  },
];
