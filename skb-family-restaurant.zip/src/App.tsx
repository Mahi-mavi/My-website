/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar.tsx';
import Hero from './components/Hero.tsx';
import About from './components/About.tsx';
import WhyChooseUs from './components/WhyChooseUs.tsx';
import MenuSection from './components/MenuSection.tsx';
import GallerySection from './components/GallerySection.tsx';
import ReviewsSection from './components/ReviewsSection.tsx';
import LocationContact from './components/LocationContact.tsx';
import CTASection from './components/CTASection.tsx';
import Footer from './components/Footer.tsx';
import MobileQuickBar from './components/MobileQuickBar.tsx';

export default function App() {
  return (
    <div className="min-h-screen bg-[#121110] text-[#f7f4ed] flex flex-col selection:bg-[#c2410c] selection:text-white">
      {/* Sticky Navigation */}
      <Navbar />

      {/* Main Page Landmark */}
      <main id="main-content" className="flex-grow">
        {/* 1. Hero Section */}
        <Hero />

        {/* 2. About Section */}
        <About />

        {/* 3. Why Choose Us */}
        <WhyChooseUs />

        {/* 4. Menu Section */}
        <MenuSection />

        {/* 5. Gallery Section with Lightbox */}
        <GallerySection />

        {/* 6. Reviews Section with Aggregate Metrics */}
        <ReviewsSection />

        {/* 7. Location & Contact Section */}
        <LocationContact />

        {/* 8. Call to Action Banner */}
        <CTASection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile-only Sticky Quick Action Bar */}
      <MobileQuickBar />
    </div>
  );
}
