export interface NavLinkItem {
  name: string;
  href: string;
  id: string;
}

export interface WhyChooseItem {
  id: string;
  title: string;
  description: string;
  iconName: 'users' | 'utensils' | 'award' | 'armchair';
}

export interface MenuCategoryItem {
  id: string;
  name: string;
  description: string;
  items: {
    name: string;
    description: string;
    tag?: string;
  }[];
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: 'ambiance' | 'dishes' | 'gathering';
  imageUrl: string;
  altText: string;
}
