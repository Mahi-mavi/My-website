import { Phone, MessageCircle, Navigation } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function MobileQuickBar() {
  return (
    <aside
      id="mobile-quick-action-bar"
      aria-label="Mobile quick actions"
      className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#121110]/95 backdrop-blur-lg border-t border-[#332d26] p-2.5 px-4 flex items-center justify-between gap-2 shadow-2xl"
    >
      {/* Direct Call Button */}
      <a
        id="mobile-bar-call"
        href={RESTAURANT_INFO.phoneTelLink}
        className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-xs shadow-md active:scale-95 transition-transform"
      >
        <Phone className="w-3.5 h-3.5 fill-current" />
        <span>Call Now</span>
      </a>

      {/* WhatsApp Button */}
      <a
        id="mobile-bar-whatsapp"
        href={RESTAURANT_INFO.whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#221f1c] border border-[#25D366]/40 text-[#55e88c] font-semibold text-xs active:scale-95 transition-transform"
      >
        <MessageCircle className="w-3.5 h-3.5" />
        <span>WhatsApp</span>
      </a>

      {/* Directions Button */}
      <a
        id="mobile-bar-directions"
        href={RESTAURANT_INFO.mapsSearchLink}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Get directions to SKB Family Restaurant"
        className="p-2.5 rounded-xl bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] active:scale-95 transition-transform"
      >
        <Navigation className="w-4 h-4 text-[#d99a38]" />
      </a>
    </aside>
  );
}
