import { useState, useEffect } from 'react';
import { Phone, Menu as MenuIcon, X, MapPin } from 'lucide-react';
import { RESTAURANT_INFO, NAV_LINKS } from '../data/restaurantData.ts';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Simple active section spy
      const sections = NAV_LINKS.map(link => link.id);
      const scrollPosition = window.scrollY + 120;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#121110]/95 backdrop-blur-md border-b border-[#332d26] py-3 shadow-xl'
          : 'bg-gradient-to-b from-[#121110]/90 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo / Branding */}
          <a
            href="#hero"
            id="nav-logo"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('#hero');
            }}
            className="group flex items-center gap-3 text-left focus:outline-none focus:ring-2 focus:ring-[#d99a38] rounded-lg p-1"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d99a38] to-[#c2410c] flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-300">
              <span className="text-[#121110] font-bold text-lg font-serif">S</span>
            </div>
            <div>
              <span className="block font-serif text-lg sm:text-xl font-bold tracking-tight text-[#fbf8f2] group-hover:text-[#f5b754] transition-colors">
                SKB Family Restaurant
              </span>
              <span className="flex items-center gap-1 text-xs text-[#d8d0c4]/80 tracking-wider uppercase font-medium">
                <MapPin className="w-3 h-3 text-[#d99a38]" />
                Angara, Ranchi
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav aria-label="Main Navigation" className="hidden md:flex items-center gap-1 lg:gap-2">
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  id={`nav-link-${link.id}`}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(link.href);
                  }}
                  className={`px-3.5 py-2 rounded-full text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#d99a38] ${
                    isActive
                      ? 'text-[#fbf8f2] bg-[#221f1c] border border-[#d99a38]/40 shadow-sm'
                      : 'text-[#d8d0c4] hover:text-[#fbf8f2] hover:bg-[#1a1815]'
                  }`}
                >
                  {link.name}
                </a>
              );
            })}
          </nav>

          {/* Header Action CTA */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              id="nav-cta-call"
              href={RESTAURANT_INFO.phoneTelLink}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-semibold text-sm shadow-md hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#d99a38] focus:ring-offset-2 focus:ring-offset-[#121110]"
            >
              <Phone className="w-4 h-4 fill-current" />
              <span>Call Now</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              id="mobile-nav-call-icon"
              href={RESTAURANT_INFO.phoneTelLink}
              aria-label="Call restaurant directly"
              className="p-2 rounded-full bg-[#221f1c] border border-[#332d26] text-[#d99a38] hover:text-[#f5b754] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              id="mobile-menu-toggle"
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
              aria-expanded={mobileMenuOpen}
              className="p-2.5 rounded-lg bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] hover:bg-[#292521] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="md:hidden bg-[#1a1815]/98 border-b border-[#332d26] px-4 pt-3 pb-6 space-y-2 backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-200 shadow-2xl"
        >
          <div className="py-2 border-b border-[#332d26]/60 mb-2">
            <p className="text-xs uppercase tracking-wider text-[#d8d0c4]/60 px-3">Explore SKB Family</p>
          </div>
          {NAV_LINKS.map((link) => (
            <a
              key={link.id}
              id={`mobile-nav-${link.id}`}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(link.href);
              }}
              className="block px-3 py-2.5 rounded-lg text-base font-medium text-[#d8d0c4] hover:text-[#fbf8f2] hover:bg-[#221f1c] transition-colors"
            >
              {link.name}
            </a>
          ))}
          <div className="pt-4 border-t border-[#332d26] flex flex-col gap-2">
            <a
              id="mobile-drawer-call-cta"
              href={RESTAURANT_INFO.phoneTelLink}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-semibold text-base shadow-md active:scale-98 transition-transform"
            >
              <Phone className="w-4 h-4 fill-current" />
              <span>Call Now (09798832616)</span>
            </a>
            <a
              id="mobile-drawer-whatsapp-cta"
              href={RESTAURANT_INFO.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] hover:text-[#f5b754] text-sm font-medium transition-colors"
            >
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
