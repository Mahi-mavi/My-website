import { Users, UtensilsCrossed, Award, Armchair } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/restaurantData.ts';

const iconMap = {
  users: Users,
  utensils: UtensilsCrossed,
  award: Award,
  armchair: Armchair,
};

export default function WhyChooseUs() {
  return (
    <section
      id="why-us"
      aria-label="Why Choose Us"
      className="py-20 sm:py-24 bg-[#1a1815] relative border-t border-b border-[#332d26]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#221f1c] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-3">
            <span>Our Commitment</span>
          </div>
          <h2
            id="why-choose-heading"
            className="font-serif text-3xl sm:text-4xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Why Choose SKB Family Restaurant
          </h2>
          <p className="text-base text-[#d8d0c4] leading-relaxed">
            We are dedicated to providing every visitor with an enjoyable, hospitable, and delicious dining experience.
          </p>
        </div>

        {/* 4 Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_CHOOSE_US.map((item, index) => {
            const Icon = iconMap[item.iconName];
            return (
              <div
                key={item.id}
                id={`feature-card-${item.id}`}
                className="group relative p-6 sm:p-7 rounded-2xl bg-[#221f1c] border border-[#332d26] hover:border-[#d99a38]/50 hover:bg-[#292521] transition-all duration-300 shadow-md hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  {/* Icon container */}
                  <div className="w-12 h-12 rounded-xl bg-[#1a1815] border border-[#332d26] group-hover:border-[#d99a38]/40 flex items-center justify-center text-[#d99a38] mb-5 group-hover:scale-110 group-hover:text-[#f5b754] transition-all duration-300">
                    <Icon className="w-6 h-6" />
                  </div>

                  {/* Feature Title */}
                  <h3 className="font-serif text-xl font-bold text-[#fbf8f2] mb-2.5 group-hover:text-[#f5b754] transition-colors">
                    {item.title}
                  </h3>

                  {/* Feature Description */}
                  <p className="text-sm text-[#d8d0c4] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Bottom subtle indicator */}
                <div className="mt-6 pt-4 border-t border-[#332d26]/60 flex items-center justify-between text-xs text-[#d8d0c4]/60">
                  <span>Pillar {index + 1} of 4</span>
                  <div className="w-2 h-2 rounded-full bg-[#d99a38]/40 group-hover:bg-[#d99a38] transition-colors" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
