import { useState, useEffect, useCallback } from 'react';
import { Camera, X, ChevronLeft, ChevronRight, ZoomIn, Info } from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/restaurantData.ts';
import { GalleryPhoto } from '../types.ts';

export default function GallerySection() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'ambiance' | 'dishes' | 'gathering'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filteredPhotos = selectedFilter === 'all'
    ? GALLERY_PHOTOS
    : GALLERY_PHOTOS.filter((photo) => photo.category === selectedFilter);

  const openLightbox = (index: number) => {
    setLightboxIndex(index);
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
  };

  const showNext = useCallback(() => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex + 1) % filteredPhotos.length);
  }, [lightboxIndex, filteredPhotos.length]);

  const showPrev = useCallback(() => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex - 1 + filteredPhotos.length) % filteredPhotos.length);
  }, [lightboxIndex, filteredPhotos.length]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') showNext();
      if (e.key === 'ArrowLeft') showPrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, showNext, showPrev]);

  const activeLightboxPhoto: GalleryPhoto | null =
    lightboxIndex !== null ? filteredPhotos[lightboxIndex] : null;

  return (
    <section
      id="gallery"
      aria-label="Gallery Section"
      className="py-20 sm:py-28 bg-[#1a1815] relative border-b border-[#332d26]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#221f1c] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-3">
            <Camera className="w-3.5 h-3.5" />
            <span>Visual Showcase</span>
          </div>
          <h2
            id="gallery-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Restaurant Gallery
          </h2>
          <p className="text-base text-[#d8d0c4] leading-relaxed">
            Take a visual tour through our comfortable dining spaces, flavorful presentations, and relaxed family setting.
          </p>
        </div>

        {/* Demo Notice */}
        <div className="max-w-2xl mx-auto mb-8 p-3 rounded-xl bg-[#221f1c] border border-[#332d26] flex items-center justify-center gap-2 text-xs text-[#d8d0c4]">
          <Info className="w-4 h-4 text-[#d99a38] shrink-0" />
          <span>
            <strong className="text-[#fbf8f2]">Demo Photos:</strong> Representative demo photography shown. Ready to be replaced with authentic pictures of SKB Family Restaurant.
          </span>
        </div>

        {/* Category Filters */}
        <div className="flex items-center justify-center gap-2 mb-10 flex-wrap">
          {[
            { label: 'All Photos', value: 'all' },
            { label: 'Dining Ambiance', value: 'ambiance' },
            { label: 'Dishes & Food', value: 'dishes' },
            { label: 'Family Gatherings', value: 'gathering' },
          ].map((filter) => {
            const isActive = selectedFilter === filter.value;
            return (
              <button
                key={filter.value}
                id={`gallery-filter-${filter.value}`}
                type="button"
                onClick={() => setSelectedFilter(filter.value as typeof selectedFilter)}
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-[#d99a38] text-[#121110] font-bold shadow-md'
                    : 'bg-[#221f1c] text-[#d8d0c4] hover:text-[#fbf8f2] border border-[#332d26]'
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredPhotos.map((photo, index) => (
            <div
              key={photo.id}
              id={`gallery-card-${photo.id}`}
              onClick={() => openLightbox(index)}
              className="group relative h-64 sm:h-72 rounded-2xl overflow-hidden cursor-pointer bg-[#221f1c] border border-[#332d26] shadow-md hover:shadow-xl hover:border-[#d99a38]/50 transition-all duration-300"
              role="button"
              tabIndex={0}
              aria-label={`View photo: ${photo.title}`}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  openLightbox(index);
                }
              }}
            >
              {/* Image */}
              <img
                src={photo.imageUrl}
                alt={photo.altText}
                className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500 ease-out"
                loading="lazy"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#121110]/90 via-[#121110]/30 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />

              {/* Zoom badge icon */}
              <div className="absolute top-3 right-3 p-2 rounded-full bg-[#121110]/70 text-[#fbf8f2] opacity-0 group-hover:opacity-100 transform translate-y-1 group-hover:translate-y-0 transition-all duration-300 backdrop-blur-xs">
                <ZoomIn className="w-4 h-4 text-[#d99a38]" />
              </div>

              {/* Card Caption */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="font-serif text-sm sm:text-base font-semibold text-[#fbf8f2] group-hover:text-[#f5b754] transition-colors line-clamp-1">
                  {photo.title}
                </p>
                <p className="text-xs text-[#d8d0c4]/80 mt-0.5 capitalize">
                  {photo.category === 'gathering' ? 'Family Dining' : photo.category}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Dialog */}
      {activeLightboxPhoto && (
        <div
          id="gallery-lightbox-modal"
          role="dialog"
          aria-modal="true"
          aria-label="Photo Lightbox"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#121110]/95 backdrop-blur-md animate-in fade-in duration-200"
          onClick={closeLightbox}
        >
          {/* Close button */}
          <button
            id="close-lightbox-btn"
            type="button"
            onClick={closeLightbox}
            aria-label="Close Lightbox"
            className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] hover:text-[#d99a38] hover:bg-[#292521] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Prev button */}
          <button
            id="prev-lightbox-btn"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showPrev();
            }}
            aria-label="Previous photo"
            className="absolute left-4 z-20 p-3 rounded-full bg-[#221f1c]/90 border border-[#332d26] text-[#fbf8f2] hover:text-[#d99a38] hover:bg-[#292521] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next button */}
          <button
            id="next-lightbox-btn"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showNext();
            }}
            aria-label="Next photo"
            className="absolute right-4 z-20 p-3 rounded-full bg-[#221f1c]/90 border border-[#332d26] text-[#fbf8f2] hover:text-[#d99a38] hover:bg-[#292521] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Main Photo container */}
          <div
            className="max-w-4xl max-h-[85vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative rounded-2xl overflow-hidden border border-[#332d26] shadow-2xl">
              <img
                src={activeLightboxPhoto.imageUrl}
                alt={activeLightboxPhoto.altText}
                className="max-w-full max-h-[70vh] object-contain mx-auto"
              />
            </div>
            <div className="text-center mt-4 px-4">
              <h3 className="font-serif text-lg sm:text-xl font-bold text-[#fbf8f2]">
                {activeLightboxPhoto.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#d8d0c4] mt-1">
                {lightboxIndex! + 1} of {filteredPhotos.length} • Demo Presentation Photo
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
