import { useState } from 'react';
import { Phone, MessageCircle, MapPin, ArrowUp, Heart, Mail, Send, Check, AlertCircle } from 'lucide-react';
import { RESTAURANT_INFO, NAV_LINKS } from '../data/restaurantData.ts';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavClick = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setStatus('error');
      setErrorMessage('Please enter your email address.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setStatus('error');
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      setEmail('');
    }, 600);
  };

  return (
    <footer
      id="main-footer"
      aria-label="Footer"
      className="bg-[#0e0d0c] border-t border-[#332d26] pt-14 pb-24 sm:pb-16 text-[#d8d0c4]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter Signup Section */}
        <div
          id="footer-newsletter-section"
          className="mb-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#1c1a17] via-[#221f1c] to-[#1c1a17] border border-[#332d26] shadow-xl relative overflow-hidden"
        >
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#d99a38]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Newsletter Information */}
            <div className="lg:col-span-6 space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#151412] border border-[#332d26] text-xs font-semibold text-[#d99a38] uppercase tracking-wider">
                <Mail className="w-3.5 h-3.5" />
                <span>Stay Connected</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#fbf8f2] tracking-tight">
                Join Our Family Table Newsletter
              </h3>
              <p className="text-sm text-[#d8d0c4] leading-relaxed max-w-xl">
                Subscribe to receive announcements on our upcoming kitchen specials, seasonal dishes, and festive holiday dining in Angara, Ranchi.
              </p>
            </div>

            {/* Newsletter Subscription Form */}
            <div className="lg:col-span-6">
              {status === 'success' ? (
                <div
                  id="newsletter-success-message"
                  className="p-4 rounded-2xl bg-[#1a2e1d] border border-emerald-500/40 text-emerald-300 flex items-center gap-3 animate-in fade-in duration-300"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <Check className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-[#fbf8f2]">Thank you for subscribing!</h4>
                    <p className="text-xs text-emerald-300/90 mt-0.5">
                      You are now on our list for upcoming specials and restaurant news.
                    </p>
                  </div>
                </div>
              ) : (
                <form
                  id="footer-newsletter-form"
                  onSubmit={handleNewsletterSubmit}
                  className="space-y-2"
                  noValidate
                >
                  <div className="flex flex-col sm:flex-row items-stretch gap-2.5">
                    <div className="relative flex-1">
                      <Mail className="w-4 h-4 text-[#d8d0c4]/60 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="newsletter-email-input"
                        type="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (status === 'error') setStatus('idle');
                        }}
                        placeholder="Enter your email address"
                        aria-label="Email address for newsletter"
                        disabled={status === 'loading'}
                        className="w-full pl-11 pr-4 py-3 rounded-2xl bg-[#121110] border border-[#332d26] text-[#fbf8f2] text-sm placeholder:text-[#d8d0c4]/50 focus:outline-none focus:border-[#d99a38] focus:ring-2 focus:ring-[#d99a38]/30 transition-all disabled:opacity-50"
                      />
                    </div>
                    <button
                      id="newsletter-submit-btn"
                      type="submit"
                      disabled={status === 'loading'}
                      className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-sm shadow-md hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all flex items-center justify-center gap-2 shrink-0 disabled:opacity-50 cursor-pointer"
                    >
                      {status === 'loading' ? (
                        <span>Subscribing...</span>
                      ) : (
                        <>
                          <span>Subscribe</span>
                          <Send className="w-3.5 h-3.5 fill-current" />
                        </>
                      )}
                    </button>
                  </div>

                  {status === 'error' && (
                    <div
                      id="newsletter-error-message"
                      className="flex items-center gap-1.5 text-xs text-rose-400 pl-1 pt-1 animate-in fade-in"
                    >
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  <p className="text-[11px] text-[#d8d0c4]/60 pl-1">
                    We respect your privacy. No spam, only genuine restaurant announcements.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#332d26]">
          {/* Col 1: Brand & Bio */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d99a38] to-[#c2410c] flex items-center justify-center shadow-md">
                <span className="text-[#121110] font-bold text-lg font-serif">S</span>
              </div>
              <span className="font-serif text-2xl font-bold text-[#fbf8f2]">
                {RESTAURANT_INFO.name}
              </span>
            </div>

            <p className="text-sm text-[#d8d0c4] leading-relaxed max-w-sm">
              Your welcoming family dining destination in Angara, Ranchi. Where delicious tastes and happy moments come together for families and friends.
            </p>

            {/* Quick Contact Badges */}
            <div className="space-y-2.5 pt-2">
              <div className="flex items-center gap-3 text-sm text-[#fbf8f2]">
                <LocationPinIcon />
                <span>{RESTAURANT_INFO.address}</span>
              </div>

              <div className="flex items-center gap-3 text-sm text-[#fbf8f2]">
                <CallIcon />
                <a
                  id="footer-phone-link"
                  href={RESTAURANT_INFO.phoneTelLink}
                  className="hover:text-[#f5b754] font-mono transition-colors"
                >
                  {RESTAURANT_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-3 text-sm text-[#55e88c]">
                <WhatsAppIcon />
                <a
                  id="footer-whatsapp-link"
                  href={RESTAURANT_INFO.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:underline transition-colors"
                >
                  Chat with us on WhatsApp
                </a>
              </div>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="md:col-span-4">
            <h4 className="font-serif text-base font-bold text-[#fbf8f2] uppercase tracking-wider mb-4">
              Navigation
            </h4>
            <ul className="grid grid-cols-2 gap-2 text-sm">
              {NAV_LINKS.map((link) => (
                <li key={link.id}>
                  <a
                    id={`footer-nav-${link.id}`}
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(link.href);
                    }}
                    className="hover:text-[#f5b754] transition-colors inline-block py-1 focus:outline-none focus:text-[#f5b754]"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Direct Action & Back to Top */}
          <div className="md:col-span-3 flex flex-col justify-between items-start md:items-end">
            <div>
              <h4 className="font-serif text-base font-bold text-[#fbf8f2] uppercase tracking-wider mb-3 md:text-right">
                Table & Orders
              </h4>
              <p className="text-xs text-[#d8d0c4] leading-relaxed mb-4 md:text-right">
                Call directly for inquiries, table reservations, or today&apos;s special offerings.
              </p>
              <div className="flex justify-start md:justify-end">
                <a
                  id="footer-call-cta"
                  href={RESTAURANT_INFO.phoneTelLink}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#1c1a17] border border-[#d99a38]/40 text-[#f5b754] hover:bg-[#25221e] hover:text-[#fbf8f2] text-xs font-semibold transition-all"
                >
                  <Phone className="w-3.5 h-3.5 fill-current" />
                  <span>Call {RESTAURANT_INFO.phone}</span>
                </a>
              </div>
            </div>

            {/* Back to top button */}
            <button
              id="back-to-top-btn"
              type="button"
              onClick={scrollToTop}
              aria-label="Back to top"
              className="mt-6 flex items-center gap-2 text-xs text-[#d8d0c4] hover:text-[#d99a38] transition-colors p-2 rounded-lg hover:bg-[#1a1815]"
            >
              <span>Back to top</span>
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#d8d0c4]/60">
          <p>
            © {new Date().getFullYear()} {RESTAURANT_INFO.name}. All rights reserved. Angara, Ranchi, Jharkhand.
          </p>
          <div className="flex items-center gap-1">
            <span>Crafted with</span>
            <Heart className="w-3 h-3 text-[#c2410c] fill-current" />
            <span>for delicious family dining</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function LocationPinIcon() {
  return (
    <span className="w-8 h-8 rounded-lg bg-[#1a1815] border border-[#332d26] flex items-center justify-center text-[#d99a38] shrink-0">
      <MapPin className="w-4 h-4" />
    </span>
  );
}

function CallIcon() {
  return (
    <span className="w-8 h-8 rounded-lg bg-[#1a1815] border border-[#332d26] flex items-center justify-center text-[#d99a38] shrink-0">
      <Phone className="w-4 h-4 fill-current" />
    </span>
  );
}

function WhatsAppIcon() {
  return (
    <span className="w-8 h-8 rounded-lg bg-[#1a1815] border border-[#332d26] flex items-center justify-center text-[#25D366] shrink-0">
      <MessageCircle className="w-4 h-4" />
    </span>
  );
}
