import { useState } from 'react';
import { UtensilsCrossed, Phone, Info, ArrowRight } from 'lucide-react';
import { MENU_CATEGORIES, RESTAURANT_INFO } from '../data/restaurantData.ts';
import MenuModal from './MenuModal.tsx';

export default function MenuSection() {
  const [activeCategoryId, setActiveCategoryId] = useState<string>('starters');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const activeCategory = MENU_CATEGORIES.find((cat) => cat.id === activeCategoryId) || MENU_CATEGORIES[0];

  return (
    <section
      id="menu"
      aria-label="Menu Section"
      className="py-20 sm:py-28 bg-[#121110] relative border-b border-[#332d26]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1a1815] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-3">
            <UtensilsCrossed className="w-3.5 h-3.5" />
            <span>Culinary Offerings</span>
          </div>
          <h2
            id="menu-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Explore Our Menu
          </h2>
          <p className="text-base text-[#d8d0c4] leading-relaxed">
            Thoughtfully prepared dishes for every family member. Browse our standard dining categories below.
          </p>
        </div>

        {/* Clear Note for Restaurant Owner & Guests */}
        <div className="max-w-2xl mx-auto mb-10 p-3.5 rounded-xl bg-[#1c1a17] border border-[#332d26] flex items-center justify-between gap-3 text-xs sm:text-sm text-[#d8d0c4]">
          <div className="flex items-center gap-2.5">
            <Info className="w-4 h-4 text-[#d99a38] shrink-0" />
            <span>
              <strong className="text-[#fbf8f2]">Demo Menu Template:</strong> Actual menu items & daily rates will be updated by the restaurant owner.
            </span>
          </div>
          <button
            id="menu-quick-inquire"
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="shrink-0 text-xs text-[#d99a38] hover:text-[#f5b754] underline font-medium"
          >
            Learn More
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 mb-10 gap-2 no-scrollbar scroll-smooth">
          {MENU_CATEGORIES.map((category) => {
            const isActive = activeCategoryId === category.id;
            return (
              <button
                key={category.id}
                id={`menu-category-tab-${category.id}`}
                type="button"
                onClick={() => setActiveCategoryId(category.id)}
                className={`px-5 py-2.5 rounded-full text-sm font-semibold tracking-wide whitespace-nowrap transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#d99a38] ${
                  isActive
                    ? 'bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] shadow-md scale-102'
                    : 'bg-[#1c1a17] text-[#d8d0c4] hover:text-[#fbf8f2] hover:bg-[#25221e] border border-[#332d26]'
                }`}
              >
                {category.name}
              </button>
            );
          })}
        </div>

        {/* Active Category Description */}
        <div className="text-center max-w-xl mx-auto mb-8">
          <h3 className="font-serif text-2xl font-bold text-[#fbf8f2]">
            {activeCategory.name}
          </h3>
          <p className="text-sm text-[#d8d0c4]/80 mt-1">
            {activeCategory.description}
          </p>
        </div>

        {/* Menu Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto mb-12">
          {activeCategory.items.map((item, index) => (
            <div
              key={index}
              id={`menu-item-${activeCategory.id}-${index}`}
              className="p-5 sm:p-6 rounded-2xl bg-[#1c1a17] border border-[#332d26] hover:border-[#d99a38]/40 hover:bg-[#221f1c] transition-all duration-300 flex flex-col justify-between group shadow-sm hover:shadow-md"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="font-serif text-lg font-semibold text-[#fbf8f2] group-hover:text-[#f5b754] transition-colors">
                    {item.name}
                  </h4>
                  {item.tag && (
                    <span className="shrink-0 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#2e261d] text-[#d99a38] border border-[#d99a38]/30">
                      {item.tag}
                    </span>
                  )}
                </div>
                <p className="text-sm text-[#d8d0c4] leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#332d26]/50 flex items-center justify-between text-xs">
                <span className="text-[#d8d0c4]/60 italic">Available to order</span>
                <span className="text-[#d99a38] font-medium">[Price upon order]</span>
              </div>
            </div>
          ))}
        </div>

        {/* Section CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            id="view-full-menu-cta"
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-[#221f1c] border border-[#d99a38]/60 text-[#fbf8f2] hover:text-[#f5b754] hover:bg-[#292521] hover:border-[#d99a38] font-semibold text-sm shadow-md active:scale-95 transition-all"
          >
            <span>View Full Menu Details</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <a
            id="menu-call-inquiry"
            href={RESTAURANT_INFO.phoneTelLink}
            className="flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-sm shadow-md hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>Call to Inquire Today&apos;s Specials</span>
          </a>
        </div>
      </div>

      {/* Reusable Informational Dialog */}
      <MenuModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </section>
  );
}
