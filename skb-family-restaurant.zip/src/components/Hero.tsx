import { Phone, Navigation, Star, MapPin, Sparkles } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function Hero() {
  return (
    <section
      id="hero"
      aria-label="Hero Section"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Background Image with Dark Vignette Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1920&auto=format&fit=crop"
          alt="SKB Family Restaurant warm dining atmosphere"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Layered cinematic dark gradient & vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#121110] via-[#121110]/80 to-[#121110]/60" />
        <div className="absolute inset-0 bg-radial-at-c from-transparent via-[#121110]/50 to-[#121110]/95" />
      </div>

      {/* Decorative Warm Ambient Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#d99a38]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center">
        {/* Location & Welcoming Pill */}
        <div
          id="hero-location-pill"
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#221f1c]/90 border border-[#d99a38]/30 text-[#f5b754] text-xs sm:text-sm font-medium tracking-wide mb-6 shadow-lg backdrop-blur-sm"
        >
          <MapPin className="w-3.5 h-3.5 text-[#d99a38]" />
          <span>Angara, Ranchi, Jharkhand</span>
          <span className="w-1 h-1 rounded-full bg-[#d99a38]" />
          <span className="text-[#d8d0c4]">Family Dining Destination</span>
        </div>

        {/* Main Restaurant Title */}
        <h1
          id="hero-title"
          className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-[#fbf8f2] mb-4 leading-tight drop-shadow-sm"
        >
          SKB Family Restaurant
        </h1>

        {/* Main Tagline */}
        <p
          id="hero-tagline"
          className="font-serif italic text-xl sm:text-2xl lg:text-3xl text-[#d99a38] font-normal mb-6 max-w-2xl"
        >
          &ldquo;Good Food. Great Taste. Happy Moments.&rdquo;
        </p>

        {/* Supportive Description */}
        <p
          id="hero-description"
          className="text-base sm:text-lg text-[#d8d0c4] max-w-xl mx-auto mb-8 font-normal leading-relaxed"
        >
          Experience delightful dining in a warm, family-friendly setting in Angara, Ranchi. Where flavorful food meets cherished gatherings.
        </p>

        {/* Rating Badge Card */}
        <div
          id="hero-rating-badge"
          className="inline-flex flex-wrap items-center justify-center gap-3 px-5 py-2.5 rounded-2xl bg-[#1a1815]/90 border border-[#332d26] mb-10 shadow-xl backdrop-blur-md"
        >
          <div className="flex items-center gap-1 text-[#f5b754]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-current text-[#d99a38]" />
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-white font-bold text-base tracking-tight">4.5 / 5</span>
            <span className="text-xs text-[#d8d0c4]/70">•</span>
            <span className="text-[#d8d0c4] text-xs sm:text-sm font-medium">46 Customer Reviews</span>
          </div>
        </div>

        {/* Dual Primary CTAs */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-4 w-full max-w-md">
          <a
            id="hero-cta-call"
            href={RESTAURANT_INFO.phoneTelLink}
            className="flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-base shadow-lg hover:from-[#f5b754] hover:to-[#ea580c] hover:shadow-[#d99a38]/20 hover:shadow-xl active:scale-95 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#d99a38] focus:ring-offset-2 focus:ring-offset-[#121110]"
          >
            <Phone className="w-5 h-5 fill-current" />
            <span>Call Now</span>
          </a>

          <a
            id="hero-cta-directions"
            href={RESTAURANT_INFO.mapsSearchLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] font-semibold text-base shadow-md hover:bg-[#292521] hover:border-[#d99a38]/60 hover:text-[#f5b754] active:scale-95 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
          >
            <Navigation className="w-5 h-5 text-[#d99a38]" />
            <span>Get Directions</span>
          </a>
        </div>

        {/* Quick reassuring badges */}
        <div className="mt-12 pt-6 border-t border-[#332d26]/60 flex flex-wrap items-center justify-center gap-6 text-xs text-[#d8d0c4]/70">
          <span className="inline-flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#d99a38]" />
            Family Friendly Atmosphere
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#d99a38]" />
            Delicious Fresh Food
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#d99a38]" />
            Direct Phone Reservations
          </span>
        </div>
      </div>
    </section>
  );
}
