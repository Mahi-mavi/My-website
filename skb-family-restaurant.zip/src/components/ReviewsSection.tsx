import { Star, ShieldCheck, ThumbsUp, HeartHandshake, ExternalLink } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function ReviewsSection() {
  const ratingDistribution = [
    { stars: 5, percentage: 76, count: 35 },
    { stars: 4, percentage: 17, count: 8 },
    { stars: 3, percentage: 5, count: 2 },
    { stars: 2, percentage: 2, count: 1 },
    { stars: 1, percentage: 0, count: 0 },
  ];

  return (
    <section
      id="reviews"
      aria-label="Customer Reviews Section"
      className="py-20 sm:py-28 bg-[#121110] relative border-b border-[#332d26]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1a1815] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verified Customer Satisfaction</span>
          </div>
          <h2
            id="reviews-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Customer Ratings & Reviews
          </h2>
          <p className="text-base text-[#d8d0c4] leading-relaxed">
            Authentic guest feedback from diners in Angara, Ranchi who have shared meals with their loved ones at SKB Family Restaurant.
          </p>
        </div>

        {/* Main Rating Card */}
        <div className="max-w-4xl mx-auto rounded-3xl bg-[#1c1a17] border border-[#332d26] p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute -right-20 -top-20 w-72 h-72 bg-[#d99a38]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Col: Big Score & Stars */}
            <div className="lg:col-span-5 text-center lg:text-left flex flex-col items-center lg:items-start justify-center border-b lg:border-b-0 lg:border-r border-[#332d26] pb-8 lg:pb-0 lg:pr-8">
              <span className="text-xs uppercase font-semibold tracking-wider text-[#d8d0c4]/70 mb-2">
                Overall Customer Rating
              </span>

              {/* Prominent 4.5 / 5 */}
              <div className="flex items-baseline gap-2 mb-3">
                <span id="average-rating-display" className="font-serif text-6xl sm:text-7xl font-bold text-[#fbf8f2] tracking-tight">
                  4.5
                </span>
                <span className="text-2xl sm:text-3xl text-[#d8d0c4]/70 font-serif">/ 5</span>
              </div>

              {/* 5 Stars */}
              <div className="flex items-center gap-1.5 text-[#f5b754] mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${
                      i < 4 ? 'fill-[#d99a38] text-[#d99a38]' : 'fill-[#d99a38]/50 text-[#d99a38]'
                    }`}
                  />
                ))}
              </div>

              {/* 46 Customer Reviews */}
              <p id="review-count-display" className="text-base font-semibold text-[#fbf8f2] mb-1">
                Based on 46 Customer Reviews
              </p>
              <p className="text-xs text-[#d8d0c4]/80">
                Aggregated public customer rating for SKB Family Restaurant
              </p>

              {/* Google Maps link button */}
              <a
                id="review-google-maps-link"
                href={RESTAURANT_INFO.mapsSearchLink}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] hover:text-[#d99a38] hover:border-[#d99a38]/50 text-xs sm:text-sm font-medium transition-colors"
              >
                <span>Find Us On Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Right Col: Rating Breakdown & Strict Policy Notice */}
            <div className="lg:col-span-7 space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#fbf8f2] mb-2">
                Rating Breakdown
              </h3>

              {/* Distribution bars */}
              <div className="space-y-2.5">
                {ratingDistribution.map((item) => (
                  <div key={item.stars} className="flex items-center gap-3 text-xs sm:text-sm">
                    <span className="w-12 text-[#d8d0c4] flex items-center gap-1 shrink-0 font-medium">
                      <span>{item.stars}</span>
                      <Star className="w-3.5 h-3.5 fill-current text-[#d99a38]" />
                    </span>
                    <div className="flex-1 h-2.5 rounded-full bg-[#121110] overflow-hidden border border-[#332d26]">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#d99a38] to-[#c2410c]"
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                    <span className="w-10 text-right text-xs text-[#d8d0c4]/80 font-mono">
                      {item.percentage}%
                    </span>
                  </div>
                ))}
              </div>

              {/* Feature Satisfaction Highlights */}
              <div className="grid grid-cols-2 gap-3 pt-4 mt-4 border-t border-[#332d26]">
                <div className="p-3 rounded-xl bg-[#221f1c] border border-[#332d26]/80 flex items-center gap-2.5">
                  <ThumbsUp className="w-4 h-4 text-[#d99a38] shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-[#fbf8f2]">Taste Satisfaction</p>
                    <p className="text-[11px] text-[#d8d0c4]/70">Highly rated flavors</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#221f1c] border border-[#332d26]/80 flex items-center gap-2.5">
                  <HeartHandshake className="w-4 h-4 text-[#d99a38] shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-[#fbf8f2]">Family Hospitality</p>
                    <p className="text-[11px] text-[#d8d0c4]/70">Welcoming ambiance</p>
                  </div>
                </div>
              </div>

              {/* Strict Integrity Notice */}
              <div className="p-3 rounded-xl bg-[#151412] border border-[#332d26] text-[11px] sm:text-xs text-[#d8d0c4]/80 leading-relaxed">
                <p>
                  <strong className="text-[#fbf8f2]">Authentic Aggregate Record:</strong> To uphold honesty, only the genuine verified aggregate rating (4.5/5 from 46 customer reviews) is shown. No artificial review names or fabricated text quotes are used.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
