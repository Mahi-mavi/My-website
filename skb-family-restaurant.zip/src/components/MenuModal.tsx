import { X, Phone, Utensils, AlertCircle } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

interface MenuModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MenuModal({ isOpen, onClose }: MenuModalProps) {
  if (!isOpen) return null;

  return (
    <div
      id="menu-info-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="menu-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#121110]/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-lg rounded-2xl bg-[#1c1a17] border border-[#d99a38]/40 p-6 sm:p-8 shadow-2xl animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-menu-modal"
          type="button"
          onClick={onClose}
          aria-label="Close menu modal"
          className="absolute top-4 right-4 p-2 rounded-full text-[#d8d0c4] hover:text-[#fbf8f2] hover:bg-[#292521] focus:outline-none focus:ring-2 focus:ring-[#d99a38]"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-xl bg-[#292521] text-[#d99a38] border border-[#332d26]">
            <Utensils className="w-6 h-6" />
          </div>
          <div>
            <h3 id="menu-modal-title" className="font-serif text-2xl font-bold text-[#fbf8f2]">
              Full Menu Inquiry
            </h3>
            <p className="text-xs text-[#d8d0c4]/80">SKB Family Restaurant • Angara, Ranchi</p>
          </div>
        </div>

        {/* Notice Message */}
        <div className="space-y-4 text-sm text-[#d8d0c4] leading-relaxed my-5">
          <div className="p-3.5 rounded-xl bg-[#221f1c] border border-[#332d26] flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#d99a38] shrink-0 mt-0.5" />
            <p className="text-xs sm:text-sm text-[#d8d0c4]">
              <strong className="text-[#fbf8f2]">Custom Menu Integration Ready:</strong> The complete printed menu with daily kitchen preparations and current seasonal pricing can be updated anytime by the restaurant management.
            </p>
          </div>

          <p>
            For today’s freshly prepared culinary specials, dish availability, or custom family group orders, please call the restaurant directly at{' '}
            <strong className="text-[#fbf8f2]">{RESTAURANT_INFO.phone}</strong>. Our staff is delighted to assist you with recommendations.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-[#332d26]">
          <a
            id="modal-call-btn"
            href={RESTAURANT_INFO.phoneTelLink}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-sm shadow-md hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>Call to Ask Today&apos;s Menu</span>
          </a>

          <button
            id="modal-dismiss-btn"
            type="button"
            onClick={onClose}
            className="py-3 px-5 rounded-xl bg-[#221f1c] border border-[#332d26] text-[#fbf8f2] hover:bg-[#292521] text-sm font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
