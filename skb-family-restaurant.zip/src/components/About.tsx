import { Heart, Users, UtensilsCrossed, Coffee } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function About() {
  return (
    <section
      id="about"
      aria-label="About Section"
      className="py-20 sm:py-28 bg-[#121110] relative overflow-hidden border-t border-[#332d26]/40"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Image Composition */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Primary atmospheric image */}
              <div className="relative rounded-2xl overflow-hidden border border-[#332d26] shadow-2xl group">
                <img
                  src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=900&auto=format&fit=crop"
                  alt="Warm interior dining area at SKB Family Restaurant"
                  className="w-full h-80 sm:h-96 object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121110]/80 via-transparent to-transparent" />
              </div>

              {/* Floating accent card */}
              <div className="absolute -bottom-6 -right-4 sm:-bottom-8 sm:-right-6 bg-[#1a1815] border border-[#d99a38]/40 p-4 sm:p-5 rounded-xl shadow-2xl backdrop-blur-md max-w-xs">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-[#221f1c] text-[#d99a38] shrink-0 border border-[#332d26]">
                    <Heart className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <h3 className="font-serif text-base font-semibold text-[#fbf8f2]">Family First</h3>
                    <p className="text-xs text-[#d8d0c4] mt-0.5 leading-relaxed">
                      A pleasant setting crafted for memorable gatherings with your loved ones.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative Content */}
          <div className="lg:col-span-7">
            {/* Section Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1a1815] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-4">
              <span>About Our Restaurant</span>
            </div>

            {/* Exact Title as requested */}
            <h2
              id="about-heading"
              className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-6 leading-tight"
            >
              Welcome to SKB Family Restaurant
            </h2>

            {/* Warm, safe, accurate copy */}
            <div className="space-y-4 text-base sm:text-lg text-[#d8d0c4] leading-relaxed">
              <p>
                Located in <span className="text-[#fbf8f2] font-semibold">{RESTAURANT_INFO.shortLocation}</span>, SKB Family Restaurant is dedicated to offering guests a warm, comfortable dining destination where good food and genuine hospitality come together.
              </p>
              <p>
                Whether you are planning a relaxed family lunch, an evening dinner with close friends, or a weekend get-together, our doors are open to provide a welcoming atmosphere. We take immense pride in preparing delicious meals using fresh ingredients, ensuring every visit is enjoyable and fulfilling.
              </p>
              <p className="text-[#d8d0c4]/90 text-base">
                Our focus is always on your comfort, quality experience, and the joy of sharing great taste with the people who matter most. We look forward to welcoming you and your family.
              </p>
            </div>

            {/* Core Pillars List */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8 pt-8 border-t border-[#332d26]">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#221f1c] text-[#d99a38] border border-[#332d26]">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-[#fbf8f2]">Family & Friends</h3>
                  <p className="text-xs text-[#d8d0c4]/80 mt-0.5">Spacious seating for gatherings</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#221f1c] text-[#d99a38] border border-[#332d26]">
                  <UtensilsCrossed className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-[#fbf8f2]">Delicious Taste</h3>
                  <p className="text-xs text-[#d8d0c4]/80 mt-0.5">Carefully prepared flavors</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#221f1c] text-[#d99a38] border border-[#332d26]">
                  <Coffee className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-[#fbf8f2]">Comfortable Dining</h3>
                  <p className="text-xs text-[#d8d0c4]/80 mt-0.5">Relaxed & welcoming space</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
