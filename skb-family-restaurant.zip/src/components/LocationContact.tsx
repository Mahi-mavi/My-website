import { useState } from 'react';
import { MapPin, Phone, MessageCircle, Navigation, Copy, Check, ExternalLink } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function LocationContact() {
  const [copied, setCopied] = useState(false);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(RESTAURANT_INFO.phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section
      id="contact"
      aria-label="Location and Contact Information"
      className="py-20 sm:py-28 bg-[#1a1815] relative border-b border-[#332d26]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#221f1c] border border-[#332d26] text-xs font-semibold text-[#d99a38] tracking-wide uppercase mb-3">
            <MapPin className="w-3.5 h-3.5" />
            <span>Visit & Connect</span>
          </div>
          <h2
            id="location-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Location & Contact
          </h2>
          <p className="text-base text-[#d8d0c4] leading-relaxed">
            Conveniently situated in Angara, Ranchi. Reach out via phone or WhatsApp, or get instant driving directions.
          </p>
        </div>

        {/* Two-Column Grid: Contact Card & Map Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-6xl mx-auto">
          {/* Left Column: Business Details & 3 Required CTAs */}
          <div className="lg:col-span-6 rounded-3xl bg-[#221f1c] border border-[#332d26] p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div>
              {/* Business Name */}
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#fbf8f2] mb-3">
                {RESTAURANT_INFO.name}
              </h3>
              <p className="text-sm text-[#d99a38] font-serif italic mb-6">
                &ldquo;{RESTAURANT_INFO.tagline}&rdquo;
              </p>

              {/* Address Card */}
              <div className="p-4 rounded-2xl bg-[#1a1815] border border-[#332d26] mb-4 flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-[#221f1c] text-[#d99a38] border border-[#332d26] shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-[#d8d0c4]/70 uppercase tracking-wider block mb-1">
                    Address
                  </span>
                  <p className="text-base text-[#fbf8f2] font-medium leading-snug">
                    {RESTAURANT_INFO.address}
                  </p>
                  <p className="text-xs text-[#d8d0c4]/80 mt-1">
                    Angara • Ranchi District • Jharkhand • India
                  </p>
                </div>
              </div>

              {/* Phone Card */}
              <div className="p-4 rounded-2xl bg-[#1a1815] border border-[#332d26] mb-6 flex items-start justify-between gap-3.5">
                <div className="flex items-start gap-3.5">
                  <div className="p-2.5 rounded-xl bg-[#221f1c] text-[#d99a38] border border-[#332d26] shrink-0 mt-0.5">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-[#d8d0c4]/70 uppercase tracking-wider block mb-1">
                      Direct Phone
                    </span>
                    <a
                      href={RESTAURANT_INFO.phoneTelLink}
                      className="text-xl font-bold text-[#fbf8f2] hover:text-[#f5b754] font-mono tracking-tight transition-colors"
                    >
                      {RESTAURANT_INFO.phone}
                    </a>
                    <p className="text-xs text-[#d8d0c4]/80 mt-1">
                      Available for table inquiries and menu questions
                    </p>
                  </div>
                </div>

                {/* Copy phone button */}
                <button
                  id="copy-phone-btn"
                  type="button"
                  onClick={handleCopyPhone}
                  aria-label="Copy phone number"
                  title="Copy phone number"
                  className="p-2.5 rounded-xl bg-[#221f1c] border border-[#332d26] text-[#d8d0c4] hover:text-[#fbf8f2] hover:border-[#d99a38]/40 transition-colors shrink-0"
                >
                  {copied ? (
                    <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                      <Check className="w-4 h-4" />
                      <span>Copied</span>
                    </span>
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* The 3 Required CTA Buttons */}
            <div>
              <p className="text-xs uppercase font-semibold tracking-wider text-[#d8d0c4]/70 mb-3">
                Quick Actions
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* 1. Call Now */}
                <a
                  id="contact-btn-call"
                  href={RESTAURANT_INFO.phoneTelLink}
                  className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-sm shadow-md hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all text-center"
                >
                  <Phone className="w-4 h-4 fill-current shrink-0" />
                  <span>Call Now</span>
                </a>

                {/* 2. WhatsApp */}
                <a
                  id="contact-btn-whatsapp"
                  href={RESTAURANT_INFO.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 text-[#55e88c] hover:bg-[#25D366]/30 font-bold text-sm shadow-md active:scale-95 transition-all text-center"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" />
                  <span>WhatsApp</span>
                </a>

                {/* 3. Get Directions */}
                <a
                  id="contact-btn-directions"
                  href={RESTAURANT_INFO.mapsSearchLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-[#1a1815] border border-[#332d26] text-[#fbf8f2] hover:text-[#d99a38] hover:border-[#d99a38]/50 font-semibold text-sm shadow-md active:scale-95 transition-all text-center"
                >
                  <Navigation className="w-4 h-4 text-[#d99a38] shrink-0" />
                  <span>Directions</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Map Area / Map Placeholder */}
          <div className="lg:col-span-6 rounded-3xl bg-[#221f1c] border border-[#332d26] p-4 sm:p-6 flex flex-col justify-between relative overflow-hidden shadow-xl min-h-[380px]">
            {/* Map Canvas Visual Placeholder */}
            <div className="relative w-full flex-1 rounded-2xl overflow-hidden bg-[#151412] border border-[#332d26] flex flex-col items-center justify-center text-center p-6">
              {/* Subtle map road network lines */}
              <div
                className="absolute inset-0 opacity-15"
                style={{
                  backgroundImage: `radial-gradient(#d99a38 1px, transparent 1px), linear-gradient(to right, #332d26 1px, transparent 1px), linear-gradient(to bottom, #332d26 1px, transparent 1px)`,
                  backgroundSize: '24px 24px, 48px 48px, 48px 48px',
                }}
              />

              {/* Center Map Pin Graphic */}
              <div className="relative z-10 flex flex-col items-center">
                <div className="relative flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-[#d99a38]/20 animate-ping absolute" />
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#d99a38] to-[#c2410c] text-[#121110] flex items-center justify-center shadow-2xl relative z-10">
                    <MapPin className="w-8 h-8 fill-current text-[#121110]" />
                  </div>
                </div>

                <div className="mt-4 max-w-sm">
                  <h4 className="font-serif text-lg font-bold text-[#fbf8f2]">
                    SKB Family Restaurant
                  </h4>
                  <p className="text-xs text-[#d8d0c4] mt-1">
                    Angara, Ranchi, Jharkhand, India
                  </p>
                </div>

                {/* Direct Google Maps Action inside placeholder */}
                <a
                  id="map-placeholder-open-btn"
                  href={RESTAURANT_INFO.mapsSearchLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#1c1a17] border border-[#d99a38]/60 text-[#f5b754] hover:text-[#fbf8f2] hover:bg-[#292521] text-xs sm:text-sm font-semibold transition-all shadow-md"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Map Placeholder Integration Note */}
            <div className="mt-4 pt-3 flex items-center justify-between text-xs text-[#d8d0c4]/70 px-1">
              <span>Interactive Navigation Ready</span>
              <span className="italic">Embed slot for Google Maps iframe</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
