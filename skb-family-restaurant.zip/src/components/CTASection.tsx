import { Phone, MessageCircle, UtensilsCrossed } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData.ts';

export default function CTASection() {
  return (
    <section
      id="meal-cta"
      aria-label="Call to action"
      className="py-16 sm:py-24 bg-[#121110] relative overflow-hidden"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#221f1c] via-[#1c1a17] to-[#161412] border border-[#d99a38]/40 p-8 sm:p-14 text-center shadow-2xl">
          {/* Subtle warm decorative glow */}
          <div className="absolute -top-24 -left-24 w-80 h-80 bg-[#d99a38]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-[#c2410c]/15 rounded-full blur-3xl pointer-events-none" />

          {/* Decorative Icon */}
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#292521] border border-[#d99a38]/30 text-[#d99a38] mb-6 shadow-md">
            <UtensilsCrossed className="w-7 h-7" />
          </div>

          {/* Heading */}
          <h2
            id="cta-section-title"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fbf8f2] tracking-tight mb-4"
          >
            Planning Your Next Meal?
          </h2>

          {/* Subtitle */}
          <p className="text-base sm:text-xl text-[#d8d0c4] max-w-2xl mx-auto mb-8 font-normal leading-relaxed">
            Visit SKB Family Restaurant and enjoy a great dining experience with your family and friends.
          </p>

          {/* Call & WhatsApp CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
            <a
              id="cta-call-now"
              href={RESTAURANT_INFO.phoneTelLink}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-gradient-to-r from-[#d99a38] to-[#c2410c] text-[#121110] font-bold text-base shadow-xl hover:from-[#f5b754] hover:to-[#ea580c] active:scale-95 transition-all"
            >
              <Phone className="w-5 h-5 fill-current" />
              <span>Call Now ({RESTAURANT_INFO.phone})</span>
            </a>

            <a
              id="cta-whatsapp"
              href={RESTAURANT_INFO.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-4 rounded-full bg-[#1a1815] border border-[#332d26] hover:border-[#25D366]/60 text-[#fbf8f2] hover:text-[#55e88c] font-semibold text-base shadow-md active:scale-95 transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              <span>WhatsApp Us</span>
            </a>
          </div>

          <p className="text-xs text-[#d8d0c4]/70 mt-6">
            Located in Angara, Ranchi, Jharkhand • Warm hospitality awaits you
          </p>
        </div>
      </div>
    </section>
  );
}
